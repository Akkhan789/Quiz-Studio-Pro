package com.quizstudiopro.app

import com.quizstudiopro.app.audio.EdgeTtsClient
import com.quizstudiopro.app.audio.EdgeTtsV2Drm
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class QuizStudioProUnitTest {

    @Test
    fun testReferenceVectors() {
        // Test vector 1: 1700000000.0
        val token1 = EdgeTtsV2Drm.generateSecMsGecV2(1700000000.0)
        assertEquals("2CD23A2CA0B2595A-F3C846C370E05F9CC83ACC5F995C5F5D87A4D0F14CE8936A0F902E64099E38A2", token1)

        // Test vector 2: 1710000000.0
        val token2 = EdgeTtsV2Drm.generateSecMsGecV2(1710000000.0)
        assertEquals("CBBF0F1C7124D6BF-6F19AC2CF6833F05E96712BA658B22198DA66BEBAFD9DD711E2DF256B625A022", token2)

        // Test vector 3: 1740000000.0
        val token3 = EdgeTtsV2Drm.generateSecMsGecV2(1740000000.0)
        assertEquals("11F052CEA4550B6C-04A775C16369912055C2B5CA477F4C827CF2D7138BA9C49BA326C96ECC7657CD", token3)

        // Test vector 4: 1772777580.0
        val token4 = EdgeTtsV2Drm.generateSecMsGecV2(1772777580.0)
        assertEquals("CC1D374D1C3E9421-DB37F1BFC66E03242B5A9F9420BD4A7293247A5E2F36A05F25B6ADEFE8A94A07", token4)
    }

    @Test
    fun testSecMsGecV2TokenFormat() {
        val token = EdgeTtsV2Drm.generateSecMsGecV2()
        assertNotNull(token)
        // Token format is <16 hex>-<64 hex> (81 chars total)
        assertEquals(81, token.length)
        assertTrue(token.contains("-"))
        val parts = token.split("-")
        assertEquals(2, parts.size)
        assertEquals(16, parts[0].length)
        assertEquals(64, parts[1].length)
        assertTrue(parts[0].matches(Regex("[0-9A-F]{16}")))
        assertTrue(parts[1].matches(Regex("[0-9A-F]{64}")))
    }

    @Test
    fun testClockSkewCorrection() {
        val initialSkew = EdgeTtsV2Drm.clockSkewSeconds
        val serverDate = "Thu, 05 Nov 2026 06:13:01 GMT"
        val adjusted = EdgeTtsV2Drm.adjustClockSkew(serverDate)
        assertTrue(adjusted)
        // Reset
        EdgeTtsV2Drm.clockSkewSeconds = initialSkew
    }

    @Test
    fun testMuidGeneration() {
        val muid = EdgeTtsV2Drm.generateMuid()
        assertEquals(32, muid.length)
        assertTrue(muid.matches(Regex("[0-9A-F]{32}")))
    }

    @Test
    fun testVoiceListDynamicParsing() {
        val sampleJson = """
        [
            {"ShortName": "en-US-GuyNeural", "FriendlyName": "Microsoft Guy Online (Natural) - English (United States)", "Locale": "en-US", "LocaleName": "English (United States)", "Gender": "Male"},
            {"ShortName": "en-US-JennyNeural", "FriendlyName": "Microsoft Jenny Online (Natural) - English (United States)", "Locale": "en-US", "LocaleName": "English (United States)", "Gender": "Female"},
            {"ShortName": "en-GB-RyanNeural", "FriendlyName": "Microsoft Ryan Online (Natural) - English (United Kingdom)", "Locale": "en-GB", "LocaleName": "English (United Kingdom)", "Gender": "Male"},
            {"ShortName": "ur-PK-AsadNeural", "FriendlyName": "Microsoft Asad Online (Natural) - Urdu (Pakistan)", "Locale": "ur-PK", "LocaleName": "Urdu (Pakistan)", "Gender": "Male"},
            {"ShortName": "es-ES-ElviraNeural", "FriendlyName": "Microsoft Elvira Online (Natural) - Spanish (Spain)", "Locale": "es-ES", "LocaleName": "Spanish (Spain)", "Gender": "Female"}
        ]
        """.trimIndent()

        val voices = EdgeTtsClient.parseVoicesJson(sampleJson, isOffline = false)
        assertEquals(5, voices.size)

        // Dynamic languages extracted
        val languages = voices.map { it.locale }.distinct()
        assertEquals(4, languages.size)
        assertTrue(languages.contains("en-US"))
        assertTrue(languages.contains("en-GB"))
        assertTrue(languages.contains("ur-PK"))
        assertTrue(languages.contains("es-ES"))
    }

    @Test
    fun testStrictLanguageAndGenderFiltering() {
        val sampleJson = """
        [
            {"ShortName": "en-US-GuyNeural", "FriendlyName": "Microsoft Guy Online (Natural) - English (United States)", "Locale": "en-US", "LocaleName": "English (United States)", "Gender": "Male"},
            {"ShortName": "en-US-JennyNeural", "FriendlyName": "Microsoft Jenny Online (Natural) - English (United States)", "Locale": "en-US", "LocaleName": "English (United States)", "Gender": "Female"},
            {"ShortName": "en-US-AriaNeural", "FriendlyName": "Microsoft Aria Online (Natural) - English (United States)", "Locale": "en-US", "LocaleName": "English (United States)", "Gender": "Female"},
            {"ShortName": "ur-PK-AsadNeural", "FriendlyName": "Microsoft Asad Online (Natural) - Urdu (Pakistan)", "Locale": "ur-PK", "LocaleName": "Urdu (Pakistan)", "Gender": "Male"},
            {"ShortName": "ur-PK-UzmaNeural", "FriendlyName": "Microsoft Uzma Online (Natural) - Urdu (Pakistan)", "Locale": "ur-PK", "LocaleName": "Urdu (Pakistan)", "Gender": "Female"}
        ]
        """.trimIndent()

        val allVoices = EdgeTtsClient.parseVoicesJson(sampleJson)

        // Filter 1: English (en-US) Male
        val enMale = allVoices.filter { it.locale.equals("en-US", true) && it.gender.equals("Male", true) }
        assertEquals(1, enMale.size)
        assertEquals("en-US-GuyNeural", enMale[0].shortName)

        // Filter 2: English (en-US) Female
        val enFemale = allVoices.filter { it.locale.equals("en-US", true) && it.gender.equals("Female", true) }
        assertEquals(2, enFemale.size)
        assertTrue(enFemale.any { it.shortName == "en-US-JennyNeural" })
        assertTrue(enFemale.any { it.shortName == "en-US-AriaNeural" })

        // Filter 3: Verify Urdu voices are never mixed into English
        assertTrue(enMale.none { it.locale.startsWith("ur") })
        assertTrue(enFemale.none { it.locale.startsWith("ur") })

        // Filter 4: Urdu Female
        val urFemale = allVoices.filter { it.locale.equals("ur-PK", true) && it.gender.equals("Female", true) }
        assertEquals(1, urFemale.size)
        assertEquals("ur-PK-UzmaNeural", urFemale[0].shortName)
    }

    @Test
    fun testHttpErrorHandlingMessages() {
        val msg401 = when (401) {
            401 -> "HTTP 401 Unauthorized: Microsoft rejected the trusted client token."
            403 -> "HTTP 403 Forbidden: Handshake rejected by Edge TTS service."
            else -> "WebSocket failure"
        }
        assertTrue(msg401.contains("401 Unauthorized"))

        val msg403 = when (403) {
            401 -> "HTTP 401 Unauthorized"
            403 -> "HTTP 403 Forbidden: Handshake rejected by Edge TTS service."
            else -> "WebSocket failure"
        }
        assertTrue(msg403.contains("403 Forbidden"))
    }

    @Test
    fun testFramePtsCalculationMultipleFps() {
        // 24 FPS
        val fps24 = 24
        val frameIndex120 = 120
        val ptsNs24 = frameIndex120.toLong() * 1_000_000_000L / fps24
        assertEquals(5_000_000_000L, ptsNs24) // 5 seconds in ns

        // 30 FPS
        val fps30 = 30
        val frameIndex150 = 150
        val ptsNs30 = frameIndex150.toLong() * 1_000_000_000L / fps30
        assertEquals(5_000_000_000L, ptsNs30) // 5 seconds in ns

        // 15 FPS
        val fps15 = 15
        val frameIndex75 = 75
        val ptsNs15 = frameIndex75.toLong() * 1_000_000_000L / fps15
        assertEquals(5_000_000_000L, ptsNs15) // 5 seconds in ns
    }

    @Test
    fun testAudioSampleToPtsMapping() {
        val sampleRate = 48000
        val sampleIndex = 24000L
        val ptsUs = sampleIndex * 1_000_000L / sampleRate
        assertEquals(500_000L, ptsUs) // 0.5 seconds in us

        val sampleIndex48000 = 48000L
        val ptsUs1s = sampleIndex48000 * 1_000_000L / sampleRate
        assertEquals(1_000_000L, ptsUs1s) // 1.0 seconds in us
    }

    @Test
    fun testProjectJsonFormatBackwardCompatibility() {
        val projectJsonStr = """
        {
          "app": "Quiz Studio Pro",
          "version": 1,
          "title": "Science Quiz",
          "channelName": "Quiz Channel",
          "settings": {
            "cdSound": "clock",
            "timerDuration": "10",
            "timerStyle": "spanish",
            "ratio": "16/9"
          },
          "questions": [
            {
              "question": "What is H2O?",
              "options": ["Water", "Air", "Fire", "Earth"],
              "correct": 0
            }
          ]
        }
        """.trimIndent()

        val obj = JSONObject(projectJsonStr)
        assertEquals("Quiz Studio Pro", obj.getString("app"))
        assertEquals("Science Quiz", obj.getString("title"))
        val questions = obj.getJSONArray("questions")
        assertEquals(1, questions.length())
        val q0 = questions.getJSONObject(0)
        assertEquals("What is H2O?", q0.getString("question"))
        assertEquals(0, q0.getInt("correct"))
    }
}
